package com.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Hostel;
import com.model.Training;
import com.service.AdminServiceIntf;


@Controller("adminController")
public class AdminController {

	@Autowired
	AdminServiceIntf adminservice;
	
	@RequestMapping(value="/viewtrainingsbyadmin",method=RequestMethod.GET)
	public ModelAndView getQueryform(){
	 List<Training> list = adminservice.getTraining();
	 ModelAndView mav = new ModelAndView("viewtrainingsbyadmin");
	 mav.addObject("list",list);
	 return mav;
		
	}
	
	@RequestMapping(value="/approveonlytrainingbyadmin",method=RequestMethod.GET)
	public ModelAndView ViewUser1(HttpServletRequest request){
		int tid =Integer.parseInt(request.getParameter("tid"));
		
		int res= adminservice.approvedonlyTrainingbyadmin(tid);
		System.out.println(tid);
		ModelAndView mav=new ModelAndView("adminindex");
		return  mav;
	}	
	@RequestMapping(value="/viewhostelsbyadmin",method=RequestMethod.GET)
	public ModelAndView getQueryform1(){
	 List<Hostel> list = adminservice.getHostel();
	 ModelAndView mav = new ModelAndView("viewhostelsbyadmin");
	 mav.addObject("list",list);
	 return mav;
		
	}
	@RequestMapping(value="/approveonlyhostelbyadmin",method=RequestMethod.GET)
	public ModelAndView ViewUser11(HttpServletRequest request){
		int hid =Integer.parseInt(request.getParameter("hid"));
		
		int res= adminservice.approvedonlyHostelbyadmin(hid);
		System.out.println(hid);
		ModelAndView mav=new ModelAndView("adminindex");
		return  mav;
	}	
	
	@RequestMapping(value = "/about", method = RequestMethod.GET)
	public ModelAndView about(HttpServletRequest request, HttpServletResponse response) 
	{
	    ModelAndView mav = new ModelAndView("about");
	    return mav;
	}
}