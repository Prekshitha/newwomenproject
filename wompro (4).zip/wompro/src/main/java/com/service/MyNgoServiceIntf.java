package com.service;

import java.util.List;

import com.model.Hostel;
import com.model.Ngotable;
import com.model.Training;
import com.model.Workingwomen;

public interface MyNgoServiceIntf {

	boolean insertngo(Ngotable ngo);

	boolean inserttraining(Training training);

	List<Training> getTraining();

	boolean insertForm(Hostel hostel);

	List<Hostel> getUserh();

	public int approvedhostelList(int nid);
	
	public List<Ngotable> approvedhostelsrecords();
	
	public Ngotable getNgo(String username);
	public Ngotable getNgo1(String username);
	public int approvedNgoTrainingList(int nid);
	public int approvedonlyTraining(int tid);
	public Ngotable checkId(String userid);
	public List<Workingwomen> search(String name);
	
	public List<Training> getMytraining(String userid);
	public List<Hostel> getMyhostels(String userid);
}
