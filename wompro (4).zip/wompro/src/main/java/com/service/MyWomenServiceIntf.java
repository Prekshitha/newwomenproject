package com.service;

import java.util.List;

import com.model.Hostel;
import com.model.Workingwomen;

public interface MyWomenServiceIntf {
	public boolean insertWorkingwomen(Workingwomen ww);
	public List<Workingwomen> getUsers(String userid);
	public int approvedList(int wid);
	public List<Workingwomen> approvedrecords(String userid);
	public String checkEmailNgo(Workingwomen ww);
	public List<Hostel> getapprovedHostel();
	public Workingwomen checkId(String userid);
}


