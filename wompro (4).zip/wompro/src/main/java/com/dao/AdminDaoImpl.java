package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.model.Hostel;
import com.model.Training;

@Repository("admindao")
   public class AdminDaoImpl implements AdminDaoIntf {

	@PersistenceContext
	EntityManager em;
	
	public List<Training> gettraining(){
		List<Training>  list =em.createQuery("SELECT t FROM Training t where status='Not Approved'").getResultList();
		return list;
	}

	public int approvedonlyTrainingbyadmin(int tid) {
		String sql= " Update Training n set n.status=:status where n.tid=:tid";
		Query query = em.createQuery(sql).setParameter("status","approved").setParameter("tid",tid);
		int result = query.executeUpdate();
        System.out.println("training called");
		System.out.println("dao is called");
		return result;
		
	}
	public List<Hostel> gethostel(){
		List<Hostel>  list =em.createQuery("SELECT t FROM Hostel t where status='Not Approved'").getResultList();
		return list;
	}

	public int approvedonlyHostelbyadmin(int hid) {
		String sql= " Update Hostel n set n.status=:status where n.hid=:hid";
		Query query = em.createQuery(sql).setParameter("status","approved").setParameter("hid",hid);
		int result = query.executeUpdate();
        System.out.println("hostel called");
		System.out.println("dao is called");
		return result;	}
}