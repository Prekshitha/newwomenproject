package com.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import com.model.Hostel;
import com.model.Ngotable;
import com.model.Training;
import com.model.Workingwomen;


@Repository("MyNgoDao")
public class MyNgoDaoImpl implements MyNgoDaoIntf{

	
	@PersistenceContext
	EntityManager em;
	
	public boolean insertngo(Ngotable ngo) {
		boolean result=false;

		
				try{
					
					em.persist(ngo);
					
		            result=true;
		            em.close();
		         
					
				}
				catch(Exception ee){
					System.out.println(ee.getMessage());
				}
				
				return result;
	}

	public List<Ngotable> getNgo() {
		
		@SuppressWarnings("unchecked")
		List<Ngotable> list=em.createQuery("SELECT n FROM ngo n").getResultList();
		System.out.println("dao is called");
		return list;
	
	}

	public boolean inserttraining(Training training) {
boolean result=false;
		
		try{
		
			em.persist(training);
			
			
            result=true;
            em.close();
          
			
		}
		catch(Exception ee){
			System.out.println(ee.getMessage());
		}
		
		return result;
	}

	public List<Training> gettraining() {
		
		@SuppressWarnings("unchecked")
		List<Training> list=em.createQuery("SELECT t FROM Training t").getResultList();
	
		return list;
	
	}

	public boolean insertForm(Hostel hostel) {

		boolean flag=false;
		try{
			
			em.persist(hostel);
			
		    em.close();
		   
		    flag=true;
		
			}
			catch (Exception e){
				System.out.println("Error"+e);
			}
		
		return flag;
	}


	
	public List<Hostel> getUserh() {
		@SuppressWarnings("unchecked")
		List<Hostel> list= em.createQuery("SELECT h FROM Hostel h").getResultList();
		return list;
	}

	public int approvedhostelList(int nid) {
		String sql= " Update Ngotable u set u.status=:status where u.nid=:nid";
		Query query = em.createQuery(sql).setParameter("status","true").setParameter("nid",nid);
		int result = query.executeUpdate();


		return result;
	}

	public List<Ngotable> approvedhostelsrecords() {
		//List<Hostel> list=em.createQuery("SELECT u FROM Hostel u where u.status=:status").setParameter("status", "true").getResultList();
		@SuppressWarnings("unchecked")
		List<Ngotable> list=em.createQuery("SELECT u FROM Ngotable u where u.status=:status").setParameter("status", "true").getResultList();
		
		return list;
	}

	public Ngotable getNgo(String username){
	
		Ngotable ngo=(Ngotable)em.createQuery("SELECT u FROM Ngotable u where u.users.userid=:username").setParameter("username", username).getSingleResult();
		
		
		return ngo;
		
		
		
		
	}

	public Ngotable getNgo1(String username) {
	
		Ngotable ngo=(Ngotable)em.createQuery("SELECT u FROM Ngotable u where u.users.userid=:username").setParameter("username", username).getSingleResult();

		return ngo;
	}

	public int approvedNgoTrainingList(int nid) {
		String sql= " Update Ngotable n set n.status=:status where n.nid=:nid";
		Query query = em.createQuery(sql).setParameter("status","approved").setParameter("nid",nid);
		int result = query.executeUpdate();

	
		return result;
	}

	public int approvedonlyTraining(int tid) {
		String sql= " Update Ngotable n set n.training.status=:status where n.training.tid=:tid";
		Query query = em.createQuery(sql).setParameter("status","approved").setParameter("tid",tid);
		int result = query.executeUpdate();
    
		return result;
		
	}

	public Ngotable checkId(String userid) 
	{
		Ngotable res = null;
		try{
			res=   (Ngotable) em.createQuery("SELECT u FROM Ngotable u where u.users.userid=:userid").setParameter("userid", userid).getSingleResult();
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return res;

	}

	public List<Training> getMytraining(String userid) {
		
		List<Training>  list =em.createQuery("SELECT t FROM Training t where t.ngo.nid=(select n from Ngotable n where n.users.userid=:userid)").setParameter("userid",userid).getResultList();
		return list;
	}

	public List<Hostel> getMyhostels(String userid) {
		List<Hostel>  list =em.createQuery("SELECT t FROM Hostel t where t.ngo.nid=(select n from Ngotable n where n.users.userid=:userid)").setParameter("userid",userid).getResultList();
		return list;
	}

	public List<Workingwomen> search(String name) 
	{
		// TODO Auto-generated method stub
		
		@SuppressWarnings("unchecked")
	List<Workingwomen> list = em.createQuery("SELECT u FROM Workingwomen u where u.name=:name").setParameter("name",name).getResultList();

		return list;
	}
}










