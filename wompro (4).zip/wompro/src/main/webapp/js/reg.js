
function valids()
	{
		var flag=true;

		var name = document.getElementById('name').value;
		var id1 = document.getElementById('id1');
		var regex = /^[a-zA-Z ]{3,}$/;
		if(name=='' || name.length==0)
		{
		    id1.innerHTML='Please fill Name';
			id1.style.color = "red";
		    flag=false;
		}
		else if(regex.test(name) == false)
		{
		     id1.innerHTML="Name must be in alphabets only";
		     id1.style.color = "red";
		     flag=false;
		}
		
		var username = document.getElementById('username').value;
		var id2 = document.getElementById('id2');
		var userregex = /^[a-zA-Z0-9 ]{6,}$/;
		id2.innerHTML='';
		if(username=='' || username.length==0)
		{
		    id2.innerHTML='Please fill User Name';
			id2.style.color = "red";
		    flag=false;
		}
		else if(userregex.test(username) == false)
		{
		     id2.innerHTML="Username must be in alphabets and numbers only";
		     id2.style.color = "red";
		     flag=false;
		}
		
		var date_of_birth = document.getElementById('date_of_birth').value;
		var id3 = document.getElementById('id3');
		var dobregex = /^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
		id3.innerHTML='';
		if(date_of_birth=='' || date_of_birth.length==0)
		{
		    id3.innerHTML='Please fill Date of Birth';
			id3.style.color = "red";
		    flag=false;
		}
		else 
		{
		    var date1 = new Date();
		    var date2 = new Date(date_of_birth);
		    if(date1.getFullYear()-date2.getFullYear()<18)
		    {
		    id3.innerHTML="Min. age should be 18 yrs.";
		    id3.style.color="red";
		    flag= false;}
		 }
		
	
		var email_id = document.getElementById('email_id').value;
		var id4 = document.getElementById('id4');
		var emailregex = /^([a-z 0-9\.-]+)@([a-z 0-9-]+).([a-z]{2,8})$/;
		id4.innerHTML='';
		if(email_id=='' || email_id.length==0)
		{
		    id4.innerHTML='Please fill Email ID';
			id4.style.color = "red";
		    flag=false;
		}
		else if(emailregex.test(email_id) == false)
		{
		     id4.innerHTML="Fill the Email Id Properly";
		     id4.style.color = "red";
		     flag=false;
		}
		
		
		var contact_number = document.getElementById('contact_number').value;
		var id5 = document.getElementById('id5');
		var conregex = /^([0-9]){10,10}$/;
		id5.innerHTML='';
		if(contact_number=='' || contact_number.length==0)
		{
		    id5.innerHTML='Please fill Contact Number';
			id5.style.color = "red";
		    flag=false;
		}
		else if(conregex.test(contact_number) == false)
		{
		     id5.innerHTML="Fill the Contact Number Properly";
		     id5.style.color = "red";
		     flag=false;
		}

		
	/*	*/
	
		var password = document.getElementById('password').value;
		var id7 = document.getElementById('id7');
		id7.innerHTML='';
		if(password=='' || password.length==0)
		{
		    id7.innerHTML='Please fill Password';
			id7.style.color = "red";
		    flag=false;
		}

		return flag;
	}	
 


function hostel()
{
	var flag=true;

	var name = document.getElementById('name').value;
	var id1 = document.getElementById('id1');
	var regex = /^[a-zA-Z ]{3,}$/;
	if(name=='' || name.length==0)
	{
	    id1.innerHTML='Please fill Name';
		id1.style.color = "red";
	    flag=false;
	}
	else if(regex.test(name) == false)
	{
	     id1.innerHTML="Name must be in alphabets only";
	     id1.style.color = "red";
	     flag=false;
	}
	
	

	var address = document.getElementById('address').value;
	var id9 = document.getElementById('id9');
	id9.innerHTML='';
	if(address=='' || address.length==0)
	{
	    id9.innerHTML='Please fill Address';
		id9.style.color = "red";
	    flag=false;
	}
	
	var roomcount = document.getElementById('roomcount').value;
	var id6 = document.getElementById('id6');
	var roomregex = /^([0-9]){4,4}$/;
	id6.innerHTML='';
	if(roomcount=='' || roomcount.length==0)
	{
	    id6.innerHTML='Please fill Room Count';
		id6.style.color = "red";
	    flag=false;
	}
	else if(roomregex.test(roomcount) == false)
	{
	     id6.innerHTML="Fill the Room Count Properly";
	     id6.style.color = "red";
	     flag=false;
	}
	
	
	return flag;
	
}

function ngo()
{
	var flag=true;

	var nname = document.getElementById('nname').value;
	var id1 = document.getElementById('id1');
	var regex = /^[a-zA-Z ]{3,}$/;
	if(nname=='' || nname.length==0)
	{
	    id1.innerHTML='Please fill Name';
		id1.style.color = "red";
	    flag=false;
	}
	else if(regex.test(nname) == false)
	{
	     id1.innerHTML="Name must be in alphabets only";
	     id1.style.color = "red";
	     flag=false;
	}
	
	var nman = document.getElementById('nman').value;
	var id2 = document.getElementById('id2');
	var regex = /^[a-zA-Z ]{3,}$/;
	if(nman=='' || nman.length==0)
	{
	    id2.innerHTML='Please fill Manager Name';
		id2.style.color = "red";
	    flag=false;
	}
	else if(regex.test(nman) == false)
	{
	     id2.innerHTML="Name must be in alphabets only";
	     id2.style.color = "red";
	     flag=false;
	}
	
	var contact = document.getElementById('contact').value;
	var id5 = document.getElementById('id5');
	var conregex = /^([0-9]){10,10}$/;
	id5.innerHTML='';
	if(contact=='' || contact.length==0)
	{
	    id5.innerHTML='Please fill Contact Number';
		id5.style.color = "red";
	    flag=false;
	}
	else if(conregex.test(contact) == false)
	{
	     id5.innerHTML="Fill the Contact Number Properly";
	     id5.style.color = "red";
	     flag=false;
	}
	
	var address = document.getElementById('address').value;
	var id9 = document.getElementById('id9');
	id9.innerHTML='';
	if(address=='' || address.length==0)
	{
	    id9.innerHTML='Please fill Address';
		id9.style.color = "red";
	    flag=false;
	}
	return flag;
	
}


function query()
{
	var flag=true;

	var name = document.getElementById('name').value;
	var id1 = document.getElementById('id1');
	var regex = /^[a-zA-Z ]{3,}$/;
	if(name=='' || name.length==0)
	{
	    id1.innerHTML='Please fill Name';
		id1.style.color = "red";
	    flag=false;
	}
	else if(regex.test(name) == false)
	{
	     id1.innerHTML="Name must be in alphabets only";
	     id1.style.color = "red";
	     flag=false;
	}
	
	var ano = document.getElementById('ano').value;
	var id8 = document.getElementById('id8');
	var anoregex =  /^([0-9]){12,12}$/;
	id8.innerHTML='';
	if(ano=='' || ano.length==0)
	{
	    id8.innerHTML='Please fill Aadhar Number';
		id8.style.color = "red";
	    flag=false;
	}
	else if(anoregex.test(roomcount) == false)
	{
	     id8.innerHTML="Fill the Aadhar Number Properly";
	     id8.style.color = "red";
	     flag=false;
	}
	var address = document.getElementById('address').value;
	var id9 = document.getElementById('id9');
	id9.innerHTML='';
	if(address=='' || address.length==0)
	{
	    id9.innerHTML='Please fill Address';
		id9.style.color = "red";
	    flag=false;
	}
	
	var date = document.getElementById('date').value;
	var id3 = document.getElementById('id3');
	var dobregex = /^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
	id3.innerHTML='';
	if(date=='' || date.length==0)
	{
	    id3.innerHTML='Please fill Date of Birth';
		id3.style.color = "red";
	    flag=false;
	}
	else 
	{
	    var date1 = new Date();
	    var date2 = new Date(date);
	    if(date1.getFullYear()-date2.getFullYear()<18)
	    {
	    id3.innerHTML="Min. age should be 18 yrs.";
	    id3.style.color="red";
	    flag= false;}
	 }
	
	var contact = document.getElementById('contact').value;
	var id5 = document.getElementById('id5');
	var conregex = /^([0-9]){10,10}$/;
	id5.innerHTML='';
	if(contact=='' || contact.length==0)
	{
	    id5.innerHTML='Please fill Contact Number';
		id5.style.color = "red";
	    flag=false;
	}
	else if(conregex.test(contact) == false)
	{
	     id5.innerHTML="Fill the Contact Number Properly";
	     id5.style.color = "red";
	     flag=false;
	}
	
	var date1 = document.getElementById('date1').value;
	var id10 = document.getElementById('id10');
	var dobregex = /^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
	id10.innerHTML='';
	if(date1=='' || date1.length==0)
	{
	    id10.innerHTML='Please fill Date of Birth';
		id10.style.color = "red";
	    flag=false;
	}
	else 
	{
	    var date11 = new Date();
	    var date22 = new Date(date1);
	    if(date11.getFullYear()-date22.getFullYear()<10)
	    {
	    id10.innerHTML="Age should be less than 10 yrs.";
	    id10.style.color="red";
	    flag= false;}
	 }
	
	var gi = document.getElementById('gi').value;
	var id8 = document.getElementById('id8');
	var roomregex = /^([0-9]){10}$/;
	id8.innerHTML='';
	if(gi=='' || gi.length==0)
	{
	    id8.innerHTML='Please fill Gross Income';
		id8.style.color = "red";
	    flag=false;
	}
	else if(roomregex.test(gi) == false)
	{
	     id8.innerHTML="Fill the Gross Income Properly";
	     id8.style.color = "red";
	     flag=false;
	}
	return flag;
}





function suka()
{
	
	var flag=true;

	var gname = document.getElementById('gname').value;
	var id1 = document.getElementById('id1');
	var regex = /^[a-zA-Z ]{3,}$/;
	if(gname=='' || gname.length==0)
	{
	    id1.innerHTML='Please fill Name';
		id1.style.color = "red";
	    flag=false;
	}
	else if(regex.test(gname) == false)
	{
	     id1.innerHTML="Name must be in alphabets only";
	     id1.style.color = "red";
	     flag=false;
	}

	
	var cname = document.getElementById('cname').value;
	var id2 = document.getElementById('id2');
	var regex1 = /^[a-zA-Z ]{3,}$/;
	if(cname=='' || cname.length==0)
	{
	    id2.innerHTML='Please fill Name';
		id2.style.color = "red";
	    flag=false;
	}
	else if(regex1.test(cname) == false)
	{
	     id2.innerHTML="Name must be in alphabets only";
	     id2.style.color = "red";
	     flag=false;
	}
	
	var udob = document.getElementById('udob').value;
	var id3 = document.getElementById('id3');
	var dobregex = /^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
	id3.innerHTML='';
	if(udob=='' || udob.length==0)
	{
	    id3.innerHTML='Please fill Date of Birth';
		id3.style.color = "red";
	    flag=false;
	}
	else
	{
	    var date11 = new Date();
	    var date22 = new Date(udob);
	    if(date11.getFullYear()-date22.getFullYear()<10)
	    {
	    id3.innerHTML="Age should be less than 10 yrs.";
	    id3.style.color="red";
	    flag= false;
	   }
	    
	 }
	var gaadhar = document.getElementById('gaadhar').value;
	var id8 = document.getElementById('id8');
	var anoregex =  /^([0-9]){12,12}$/;
	id8.innerHTML='';
	if(gaadhar=='' || gaadhar.length==0)
	{
	    id8.innerHTML='Please fill Aadhar Number';
		id8.style.color = "red";
	    flag=false;
	}
	else if(anoregex.test(gaadhar) == false)
	{
	     id8.innerHTML="Fill the Aadhar Number Properly";
	     id8.style.color = "red";
	     flag=false;
	}
	var address = document.getElementById('address').value;
	var id9 = document.getElementById('id9');
	id9.innerHTML='';
	if(address=='' || address.length==0)
	{
	    id9.innerHTML='Please fill Address';
		id9.style.color = "red";
	    flag=false;
	}
	
	this.submit();
	/*return flag;*/
}


function train()
{

	var flag=true;
	
	var tname = document.getElementById('tname').value;
	var id1 = document.getElementById('id1');
	var regex = /^[a-zA-Z]{3,}$/;
	if(tname=='' || tname.length==0)
	{
	    id1.innerHTML='Please fill Name';
		id1.style.color = "red";
	    flag=false;
	}
	else if(regex.test(tname) == false)
	{
	     id1.innerHTML="Name must be in alphabets only";
	     id1.style.color = "red";
	     flag=false;
	}
	
	
	var sdate = document.getElementById('sdate').value;
	var id3 = document.getElementById('id3');

	id3.innerHTML='';
	if(sdate=='' || sdate.length==0)
	{
	    id3.innerHTML='Please fill Upcoming Batch Date';
		id3.style.color = "red";
	    flag=false;
	}
	
	var edate = document.getElementById('edate').value;
	var id4 = document.getElementById('id4');

	id4.innerHTML='';
	if(edate=='' || edate.length==0)
	{
	    id4.innerHTML='Please fill End Date';
		id4.style.color = "red";
	    flag=false;
	}


	
	return flag;
}