package com.dao;

import java.util.List;

import com.model.Hostel;
import com.model.Ngotable;
import com.model.Workingwomen;

public interface MyWomenDaoIntf {
	public boolean insertWorkingwomen(Workingwomen ww);
	public List<Workingwomen> getUsers();
    public List<Workingwomen> approvedrecords();
	public int approvedList(int wid);
	public String checkEmailNgo(Workingwomen ww);
	public List<Hostel> getapprovedHostel();
	
	public Workingwomen checkId(String userid);
}
