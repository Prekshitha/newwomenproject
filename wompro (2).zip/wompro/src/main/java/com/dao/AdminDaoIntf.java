package com.dao;

import java.util.List;

import com.model.Hostel;
import com.model.Training;

public interface AdminDaoIntf {
 public List<Training> gettraining();
 public int approvedonlyTrainingbyadmin(int tid);
 public List<Hostel> gethostel();
 public int approvedonlyHostelbyadmin(int hid);
}