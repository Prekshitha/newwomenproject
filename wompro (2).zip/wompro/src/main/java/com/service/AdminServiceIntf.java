package com.service;

import java.util.List;

import com.model.Hostel;
import com.model.Training;

public interface AdminServiceIntf {

	public List<Training> getTraining();
	public int approvedonlyTrainingbyadmin(int tid) ;
	public List<Hostel> getHostel();
	public int approvedonlyHostelbyadmin(int hid) ;
}