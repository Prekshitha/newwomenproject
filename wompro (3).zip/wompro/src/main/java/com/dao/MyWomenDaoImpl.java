package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.model.Hostel;
import com.model.Ngotable;
import com.model.Workingwomen;

@Repository("myWomenDao")
public class MyWomenDaoImpl implements MyWomenDaoIntf {
	@PersistenceContext
	EntityManager em;
	public boolean insertWorkingwomen(Workingwomen ww) {
		Boolean result=false;
		try{
			
			
			em.persist(ww);
			
			System.out.println("dao is called");
            result=true;
            em.close();
           
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		return result;
	}

	@SuppressWarnings("unchecked")
	public List<Workingwomen> getUsers(String userid) {
		System.out.println("userid::::::"+userid);
		@SuppressWarnings("unchecked")
		Ngotable ngo =(Ngotable) em.createQuery("select n from Ngotable n where n.users.userid=:userid").setParameter("userid", userid).getSingleResult();
		System.out.println(ngo.getNid());
		List<Workingwomen> list=em.createQuery("SELECT w FROM Workingwomen w where w.status=:status and w.nid=:nid")
	     .setParameter("status", "false")
	 	.setParameter("nid", ngo.getNid())
		.getResultList();
		System.out.println("dao is called");
		return list;
	}

	public List<Workingwomen> approvedrecords(String userid) {
		System.out.println("userid::::::"+userid);
		@SuppressWarnings("unchecked")
		Ngotable ngo =(Ngotable) em.createQuery("select n from Ngotable n where n.users.userid=:userid").setParameter("userid", userid).getSingleResult();
		System.out.println(ngo.getNid());
		List<Workingwomen> list=em.createQuery("SELECT w FROM Workingwomen w where w.status=:status and w.nid=:nid")
	     .setParameter("status", "true")
	 	.setParameter("nid", ngo.getNid())
		.getResultList();
		System.out.println("dao is called");
		return list;
	}

	public int approvedList(int wid) {
		String sql= " Update Workingwomen w set w.status=:status where w.wid=:wid";
		Query query = em.createQuery(sql).setParameter("status","true").setParameter("wid",wid);
		int result = query.executeUpdate();

		System.out.println("dao is called");
		return result;
	}

	public String checkEmailNgo(Workingwomen ww) 
	{
		int wid = ww.getWid();
		

		String u = null;
		
		try{
			
			System.out.println("u1="+u);
			
	u = (String) em.createNativeQuery("SELECT u.email_id from Users u where u.userid=(SELECT w.userid from Workingwomen w where w.wid=:wid)")
				.setParameter("wid", wid)
				.getSingleResult();

		System.out.println("u2="+u);
		}
		catch(Exception e)
		{
			System.out.println("Error "+e);
		}
		
		
		return u;
	
	}

	public List<Hostel> getapprovedHostel() {
		List<Hostel>  list =em.createQuery("SELECT t FROM Hostel t where t.status=:status and t.ngo.nobj=:nobj").setParameter("status","approved").setParameter("nobj","hostel").getResultList();
		return list;
	}

	public Workingwomen checkId(String userid) {
		Workingwomen res = null;
		try{
			res=   (Workingwomen) em.createQuery("SELECT u FROM Workingwomen u where u.users.userid=:userid").setParameter("userid", userid).getSingleResult();
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return res;
	}

}
