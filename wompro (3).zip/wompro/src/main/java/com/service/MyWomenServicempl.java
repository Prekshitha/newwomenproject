package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.MyWomenDaoIntf;
import com.model.Hostel;
import com.model.Workingwomen;

@Service("myWomenService")
public class MyWomenServicempl implements MyWomenServiceIntf {

	@Autowired(required=true)
	MyWomenDaoIntf myWomenDao;

	@Transactional
	public boolean insertWorkingwomen(Workingwomen ww) {
		System.out.println("service is called");
		boolean flag=myWomenDao.insertWorkingwomen(ww);
		return flag;
	}

	@Transactional
	public List<Workingwomen> getUsers(String userid) {
		List<Workingwomen> list=myWomenDao.getUsers(userid);
		return list;
	}

	@Transactional
	public int approvedList(int wid) {
		int result = myWomenDao.approvedList(wid);
		return result;
	}

	@Transactional
	public List<Workingwomen> approvedrecords(String userid) {
		List<Workingwomen> list=myWomenDao.approvedrecords(userid);
		return list;
	}
	@Transactional
	public String checkEmailNgo(Workingwomen ww) {
		// TODO Auto-generated method stub
		return myWomenDao.checkEmailNgo(ww);
	}

	@Transactional
	public List<Hostel> getapprovedHostel() {
		return myWomenDao.getapprovedHostel();
	}

	public Workingwomen checkId(String userid) {
		return myWomenDao.checkId(userid);
	}
}
